# Odisha Newspaper Tender Finder — Setup Guide

This turns into a free website you open every morning. You pick the date, tap one
button, and it shows you any pages from the e-paper that mention an English
tender/corrigendum for security, housekeeping, manpower, or watchman services.
You then save/share the image to WhatsApp yourself, the same way you'd share any photo.

**Cost: ₹0.** Everything below uses free tiers only.

Right now only **Samaja** is fully working. Dharitri, Sambad, and Prameya are
wired into the app but not yet connected — see the last section.

---

## Part 1 — Put the code on GitHub (one-time, ~10 minutes)

1. Go to https://github.com and click **Sign up** (free). Verify your email.
2. Once logged in, click the **+** icon (top right) → **New repository**.
3. Name it `tender-finder`. Keep it **Public**. Click **Create repository**.
4. On the new repo page, click **uploading an existing file** (a link in the
   middle of the page).
5. Drag in these three files (I've attached them to this conversation):
   - `app.py`
   - `requirements.txt`
   - `packages.txt`
6. Scroll down, click **Commit changes**.

That's it — your code is now online (privately usable, publicly hosted is fine
since it contains no personal data).

---

## Part 2 — Deploy it for free on Streamlit Cloud (~5 minutes)

1. Go to https://share.streamlit.io and click **Sign up**, choose
   **Continue with GitHub**, and approve the connection.
2. Click **Create app** → **From existing repo**.
3. Pick the `tender-finder` repository you just made.
4. Main file path: type `app.py`.
5. Click **Deploy**.
6. Wait 2–3 minutes the first time (it's installing the OCR software).
   You'll get a permanent web address like:
   `https://your-name-tender-finder.streamlit.app`

**Bookmark that link on your phone's home screen** — that's your app icon from now on.

---

## Part 3 — Using it every day

1. Open your bookmarked link.
2. Pick the date (defaults to today).
3. Leave "Samaja" selected, pick your edition/city.
4. Tap **🔍 Search for Tenders**.
5. Wait — it downloads and reads ~15–25 pages, so this can take a minute or two.
6. Any matching page shows up as an image, with the matched words listed
   underneath (e.g. "TENDER + SECURITY").
7. Long-press the image (or use the **Save this image** button) → **Share** →
   **WhatsApp** → send to **"You"**, exactly like sharing any photo.

If nothing is found, it'll tell you clearly rather than staying silent.

---

## Known limitations (please read)

- **OCR isn't perfect.** Newsprint scans, small classified-ad text, and mixed
  Odia/English pages can make the text-recognition software miss things
  occasionally. Treat this as a strong first pass, not a 100% guarantee —
  especially in the first couple of weeks, it's worth spot-checking the
  classified pages yourself now and then.
- **Only Samaja works right now.** Dharitri, Sambad, and Prameya publish their
  e-papers with a different, less predictable web structure than Samaja. I can
  wire each of them in — I just need to look at their page structure a bit
  more closely (ideally with you sending me the exact link you use to read
  today's edition of each, so I can confirm the pattern). Bring this back to me
  whenever you're ready and we'll add them one by one.
- **Newspaper sites can change their website anytime**, which could break the
  pattern this app relies on. If the app suddenly stops finding anything even
  when you know a tender was published, let me know and I'll re-check the site.
- This app reads **publicly available** e-paper pages the same way your browser
  does — no login, no paywall bypass, no scraping of anything behind a
  subscription wall.
